$('ul').owlCarousel({
  items: 5,
  addClassActive: true
});